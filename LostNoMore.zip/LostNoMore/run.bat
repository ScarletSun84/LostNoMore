@echo off
cd /d "%~dp0"
py -m pip install -r Python\requirements.txt
if errorlevel 1 (
  echo Failed to install dependencies. Check your Python installation and internet connection.
  pause
  exit /b 1
)
py Python\run.py
if errorlevel 1 pause
