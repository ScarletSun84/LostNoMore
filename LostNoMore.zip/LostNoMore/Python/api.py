from __future__ import annotations
import base64, hashlib, hmac, os, sqlite3
from functools import wraps
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory, session


class Database:
    """Small OOP database layer; every operation gets its own SQLite connection."""
    def __init__(self, path: Path):
        self.path = path

    def connect(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA foreign_keys = ON')
        conn.execute('PRAGMA busy_timeout = 10000')
        return conn


class PasswordManager:
    """Centralized password hashing and legacy hash verification."""
    ITERATIONS = 310_000
    @staticmethod
    def hash(password: str) -> str:
        salt = os.urandom(16)
        digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PasswordManager.ITERATIONS)
        return f"pbkdf2_sha256${PasswordManager.ITERATIONS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"

    @staticmethod
    def verify(password: str, stored: str) -> bool:
        if not stored:
            return False
        if stored.startswith('pbkdf2_sha256$'):
            try:
                _, rounds, salt64, digest64 = stored.split('$', 3)
                salt = base64.urlsafe_b64decode(salt64.encode())
                expected = base64.urlsafe_b64decode(digest64.encode())
                actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, int(rounds))
                return hmac.compare_digest(actual, expected)
            except (ValueError, TypeError):
                return False
        if stored.startswith('pbkdf2$'):
            legacy = 'pbkdf2$' + hashlib.pbkdf2_hmac('sha256', password.encode(), b'lostnomore_local_salt_v2', 180000).hex()
            return hmac.compare_digest(legacy, stored)
        legacy_sha = hashlib.sha256(('lostnomore_salt' + password).encode()).hexdigest()
        return hmac.compare_digest(legacy_sha, stored)


class ReportService:
    """Report business rules and persistence helpers."""
    def __init__(self, database: Database):
        self.database = database

    def list_all(self):
        with self.database.connect() as conn:
            return conn.execute('SELECT * FROM reports ORDER BY id DESC').fetchall()

    def delete(self, report_id: int) -> bool:
        with self.database.connect() as conn:
            cur = conn.execute('DELETE FROM reports WHERE id=?', (report_id,))
            return cur.rowcount > 0

ROOT = Path(__file__).resolve().parent.parent
MAIN_DIR = ROOT / 'Main'
DB_PATH = Path(__file__).resolve().parent / 'lostnomore.db'
database = Database(DB_PATH)
report_service = ReportService(database)
app = Flask(__name__, static_folder=str(MAIN_DIR), static_url_path='')
app.secret_key = os.environ.get('LOSTNOMORE_SECRET') or hashlib.sha256(str(DB_PATH).encode()).hexdigest()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')


def get_db():
    return database.connect()


def hash_password(password: str) -> str:
    return PasswordManager.hash(password)


def verify_password(password, stored):
    return PasswordManager.verify(password, stored)


def init_db():
    with get_db() as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL, phone TEXT DEFAULT '', password_hash TEXT NOT NULL,
          is_admin INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        conn.execute('''CREATE TABLE IF NOT EXISTS reports (
          id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL,
          name TEXT DEFAULT '', email TEXT DEFAULT '', phone TEXT DEFAULT '', site TEXT DEFAULT '',
          location TEXT DEFAULT '', date_lost TEXT DEFAULT '', reward TEXT DEFAULT '',
          items TEXT DEFAULT '', description TEXT DEFAULT '', image_data TEXT, hidden_info INTEGER DEFAULT 0,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        # Migrate older database schemas safely.
        user_cols = {r['name'] for r in conn.execute('PRAGMA table_info(users)')}
        if 'created_at' not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP")
        report_cols = {r['name'] for r in conn.execute('PRAGMA table_info(reports)')}
        for col, definition in [('image_data','TEXT'), ('hidden_info','INTEGER DEFAULT 0')]:
            if col not in report_cols:
                conn.execute(f'ALTER TABLE reports ADD COLUMN {col} {definition}')
        admin = conn.execute('SELECT id,password_hash FROM users WHERE lower(email)=?', ('admin@gmail.com',)).fetchone()
        if admin is None:
            conn.execute('INSERT INTO users(name,email,phone,password_hash,is_admin) VALUES(?,?,?,?,1)',
                         ('Administrator','admin@gmail.com','',hash_password('admin123')))
        elif not admin['password_hash']:
            conn.execute('UPDATE users SET password_hash=? WHERE id=?', (hash_password('admin123'), admin['id']))


def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get('user_id') or not session.get('is_admin'):
            return jsonify(success=False, message='Administrator login required.'), 401
        return fn(*args, **kwargs)
    return wrapped


def public_report(row):
    d = dict(row)
    d['date'] = d.pop('date_lost', '')
    d['imageData'] = d.pop('image_data', None)
    d['hiddenInfo'] = bool(d.pop('hidden_info', 0))
    return d

@app.get('/')
def home(): return send_from_directory(MAIN_DIR, 'index.html')

@app.get('/<path:filename>')
def static_files(filename): return send_from_directory(MAIN_DIR, filename)

@app.get('/api/auth/me')
def me():
    if not session.get('user_id'): return jsonify(success=True, user=None)
    return jsonify(success=True, user={'id':session['user_id'],'name':session['name'],'email':session['email'],'is_admin':bool(session['is_admin'])})

@app.post('/api/auth/login')
def login():
    data=request.get_json(silent=True) or {}; email=str(data.get('email','')).strip().lower(); password=str(data.get('password',''))
    with get_db() as conn: row=conn.execute('SELECT * FROM users WHERE lower(email)=?',(email,)).fetchone()
    if not row or not verify_password(password,row['password_hash']):
        return jsonify(success=False,message='Invalid email or password.'),401
    # Upgrade legacy hashes to the stronger format after successful login.
    if not row['password_hash'].startswith('pbkdf2_sha256$'):
        with get_db() as conn: conn.execute('UPDATE users SET password_hash=? WHERE id=?',(hash_password(password),row['id']))
    session.clear(); session.update(user_id=row['id'],name=row['name'],email=row['email'],is_admin=bool(row['is_admin']))
    return jsonify(success=True,user={'id':row['id'],'name':row['name'],'email':row['email'],'phone':row['phone'],'is_admin':bool(row['is_admin'])})

@app.post('/api/auth/logout')
def logout(): session.clear(); return jsonify(success=True)

@app.post('/api/auth/register')
def register():
    data=request.get_json(silent=True) or {}; name=str(data.get('name','')).strip(); email=str(data.get('email','')).strip().lower(); phone=str(data.get('phone','')).strip(); password=str(data.get('password',''))
    if len(name)<2 or not email or len(password)<6: return jsonify(success=False,message='Enter a name, valid email, and password of at least 6 characters.'),400
    try:
        with get_db() as conn: conn.execute('INSERT INTO users(name,email,phone,password_hash,is_admin) VALUES(?,?,?,?,0)',(name,email,phone,hash_password(password)))
    except sqlite3.IntegrityError: return jsonify(success=False,message='That email is already registered.'),409
    return jsonify(success=True,message='Account created successfully.'),201

@app.get('/api/reports')
def reports():
    rows = report_service.list_all()
    return jsonify(success=True,reports=[public_report(r) for r in rows])

@app.post('/api/reports')
def add_report():
    data=request.get_json(silent=True) or {}; typ=str(data.get('type','')).lower().strip()
    if typ not in ('lost','found'): return jsonify(success=False,message='Report type must be lost or found.'),400
    keys=('name','email','phone','site','location','date','reward','items','description')
    vals=[str(data.get(k,'') or '').strip() for k in keys]
    image=data.get('imageData')
    with get_db() as conn:
        cur=conn.execute('INSERT INTO reports(type,name,email,phone,site,location,date_lost,reward,items,description,image_data) VALUES(?,?,?,?,?,?,?,?,?,?,?)',[typ,*vals,image])
        rid=cur.lastrowid
    return jsonify(success=True,id=rid,message='Report created.'),201

@app.put('/api/reports/<int:rid>')
@admin_required
def update_report(rid):
    d=request.get_json(silent=True) or {}; typ=str(d.get('type','')).lower()
    if typ not in ('lost','found'): return jsonify(success=False,message='Invalid report type.'),400
    fields=['type','name','email','phone','site','location','date','reward','items','description','imageData','hiddenInfo']
    vals=[typ,str(d.get('name','')),str(d.get('email','')),str(d.get('phone','')),str(d.get('site','')),str(d.get('location','')),str(d.get('date','')),str(d.get('reward','')),str(d.get('items','')),str(d.get('description','')),d.get('imageData'),int(bool(d.get('hiddenInfo',False))),rid]
    with get_db() as conn:
        cur=conn.execute('UPDATE reports SET type=?,name=?,email=?,phone=?,site=?,location=?,date_lost=?,reward=?,items=?,description=?,image_data=?,hidden_info=? WHERE id=?',vals)
    if not cur.rowcount: return jsonify(success=False,message='Report not found.'),404
    return jsonify(success=True,message='Report updated.')

@app.delete('/api/reports/<int:rid>')
@admin_required
def delete_report(rid):
    deleted = report_service.delete(rid)
    if not deleted: return jsonify(success=False,message='Report not found.'),404
    return jsonify(success=True,message='Report deleted.')

@app.get('/api/users')
@admin_required
def users():
    with get_db() as conn: rows=conn.execute('SELECT id,name,email,phone,is_admin,created_at FROM users ORDER BY id').fetchall()
    return jsonify(success=True,users=[dict(r) for r in rows])

@app.delete('/api/users/<int:user_id>')
@admin_required
def delete_user(user_id):
    if user_id == session.get('user_id'): return jsonify(success=False,message='You cannot delete the account currently signed in.'),400
    with get_db() as conn:
        row=conn.execute('SELECT email,is_admin FROM users WHERE id=?',(user_id,)).fetchone()
        if not row: return jsonify(success=False,message='User not found.'),404
        if row['is_admin']: return jsonify(success=False,message='Administrator accounts cannot be deleted here.'),403
        conn.execute('DELETE FROM users WHERE id=?',(user_id,))
    return jsonify(success=True,message='Account deleted.')

@app.post('/api/admin/reports/<int:rid>/visibility')
@admin_required
def toggle_visibility(rid):
    with get_db() as conn:
        row=conn.execute('SELECT hidden_info FROM reports WHERE id=?',(rid,)).fetchone()
        if not row: return jsonify(success=False,message='Report not found.'),404
        value=0 if row['hidden_info'] else 1
        conn.execute('UPDATE reports SET hidden_info=? WHERE id=?',(value,rid))
    return jsonify(success=True,hiddenInfo=bool(value))

if __name__=='__main__':
    init_db(); app.run(host='127.0.0.1',port=5000,debug=False)
