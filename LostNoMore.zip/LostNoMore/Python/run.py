from pathlib import Path
import sys, webbrowser, threading, time
HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0, str(HERE))
from api import app, init_db

if __name__ == '__main__':
    init_db()
    print('LostNoMore is starting. Open http://127.0.0.1:5000 in your browser.')
    threading.Timer(1.2, lambda: webbrowser.open('http://127.0.0.1:5000')).start()
    app.run(host='127.0.0.1', port=5000, debug=False)
