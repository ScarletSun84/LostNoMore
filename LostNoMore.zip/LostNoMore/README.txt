LostNoMore - startup and report loading fix

IMPORTANT: Do not open Main\index.html directly. The browser must connect to the Python Flask server for reports, login, and database operations.

EASIEST STARTUP
1. Extract the whole ZIP folder.
2. Double-click run.bat.
3. Wait until the terminal says the app is starting.
4. Open http://127.0.0.1:5000 in your browser.
5. Keep the terminal window open while using the site.

Manual startup (PowerShell from the LostNoMore folder):
  py -m pip install -r .\Python\requirements.txt
  py .\Python\run.py

If reports still fail to load:
- Confirm the terminal window is still open and shows no traceback.
- Use exactly http://127.0.0.1:5000, not file:///.../index.html.
- If port 5000 is already in use, close the other LostNoMore server window and try again.

Initial local test administrator (change password before real use):
Email: admin@gmail.com
Password: admin123
